package de.uni_hamburg.informatik.swt.se2.mediathek.materialien;

import java.util.LinkedList;

import de.uni_hamburg.informatik.swt.se2.mediathek.materialien.medien.Medium;

/**
 * 
 * Diese Klasse dient dazu, Vormerkern für ein Medium zu notieren. 
 * Sie beantwortet die folgenden Fragen: Welches Medium wurde von wem vorgemerkt? 
 * In welcher Reihenfolge stehen die Vormerkern? 
 * 
 * Ein Vormerkkarte wird erst erstellt, wenn ein Medium mindestens einen Vormerker hat. 
 * Um die Verwaltung der Karten kümmert sich der VerleihService.
 * @author SuperGruppe
 * @version 1.0
 *
 */
public class Vormerkkarte
{
    //Eigenschaften einer Vormerkkarte
    private final Medium _medium;
    private final LinkedList<Kunde> _vormerkern;

    /**
     * Erstellt eine neue Vormerkkarte indem es einen Kunden zur Liste der Vormerker eines Medium
     * hinzufügt
     * @param vormerker
     * @param medium
     * 
     * @require vormerker != null
     * @require medium != null
     *
     * @ensure getMedium() == medium
     * @ensure getVormerker() == vormerker
     */
    public Vormerkkarte(Kunde vormerker, Medium medium)
    {

        assert vormerker != null : "Vorbedingung verletzt: vormerker ist null";
        assert medium != null : "Vorbedingung verletzt: medium ist null";

        _medium = medium;
        _vormerkern = new LinkedList<Kunde>();
        _vormerkern.add(vormerker);
    }

    /**
     * Gibt das Medium zurück. 
     *
     * @return Medium
     * @ensure result != null
     */
    public Medium getMedium()
    {
        return _medium;
    }

    /**
     * Gibt alle Vormerker zurück.
     * @return Liste aller Vormerker
     * @ensure result != null
     */
    public LinkedList<Kunde> getVormerkern()
    {
        return _vormerkern;
    }

    /**
     * Gibt den ersten Vormerker zurück.
     *
     * @return den Kunden, der auf der ersten Stelle der Liste ist 
     * und damit das Medium ausleihen darf
     * @ensure result != null
     */
    public Kunde getErsterVormerker()
    {
        return _vormerkern.getFirst();
    }

    //    /*
    //     * @ensure AnzahlAnVormerkern <= 3
    //     */
    //    public void fuegeVormerkerHinzu(Kunde neuVormerker)
    //    {
    //        _vormerkern.add(neuVormerker);
    //    }
    //
    //    public void entferneErsterVormerker()
    //    {
    //        _vormerkern.remove();
    //    }

    /*
     * Gibt zurück wie viele Vormerker auf der Liste stehen.
     *
     * @return Anzahl aller Vormerker
     * 
     */
    public int getAnzahlAnVormerkern()
    {
        return _vormerkern.size();
    }
    //
    //    /**
    //     * Prüft, ob schon von dem Kunden vorgemerkt ist.
    //     * @param Kunde
    //     * @return true, wenn der Kunde das Medium schon vorgemerkt hat; false sonst 
    //     * 
    //     */
    //    public boolean istSchonVorgemerktVon(Kunde kunde)
    //    {
    //
    //        for (int i = 0; i < _vormerkern.size(); i++)
    //        {
    //            if (kunde == _vormerkern.get(i))
    //            {
    //                return true;
    //            }
    //        }
    //
    //        return false;
    //
    //    }

}
