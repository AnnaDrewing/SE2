package de.uni_hamburg.informatik.swt.se2.mediathek.materialien;

import static org.junit.Assert.assertEquals;

import java.util.LinkedList;

import org.junit.Test;

import de.uni_hamburg.informatik.swt.se2.mediathek.fachwerte.Kundennummer;
import de.uni_hamburg.informatik.swt.se2.mediathek.materialien.medien.DVD;
import de.uni_hamburg.informatik.swt.se2.mediathek.materialien.medien.Medium;
import de.uni_hamburg.informatik.swt.se2.mediathek.services.verleih.VerleihServiceImpl;

public class VormerkkarteTest
{

    private Medium _medium;
    private Kunde _kunde1;
    private Kunde _kunde2;
    private Kunde _kunde3;
    private Vormerkkarte _vormerkkarte;
    private LinkedList<Kunde> _vormerkern;
    private VerleihServiceImpl _verleihService;

    public VormerkkarteTest()
    {

        _kunde1 = new Kunde(new Kundennummer(123456), "John", "Smith");
        _kunde2 = new Kunde(new Kundennummer(234567), "Mary", "Jane");
        _kunde3 = new Kunde(new Kundennummer(345678), "Katy", "Blake");
        _medium = new DVD("eins", "zwei", "drei", 120);
        _vormerkern = new LinkedList<Kunde>();
        _vormerkern.add(_kunde1);
        _vormerkern.add(_kunde2);
        _vormerkern.add(_kunde3);

    }

    /** 
    testet das getMedium das richtige Medium holt
    testet das eine vormerkkarte mit einem kunden diesen als ersten Vormerker hat 
    */

    @Test
    public void testKonstruktor()
    {
        _vormerkkarte = new Vormerkkarte(_kunde1, _medium);
        assertEquals(_medium, _vormerkkarte.getMedium());
        assertEquals(_kunde1, _vormerkkarte.getErsterVormerker());
    }

    /** 
    * testet das alle drei Vormerker mit getVormerkern geholt werden 
    */

    @Test
    public void testGetVormerkern()
    {
        _vormerkkarte = new Vormerkkarte(_kunde1, _medium);

        _verleihService.fuegeVormerkerHinzu(_medium, _kunde2);
        _verleihService.fuegeVormerkerHinzu(_medium, _kunde3);
        assertEquals(_vormerkern, _vormerkkarte.getVormerkern());
    }

    /** 
    testet das eine Vormerkkarte in die ein Vormerker eingetragen wurde nur einen Vormerker enthält
    testet das eine Vormerkkarte in die zwei Vormerker eingetragen wurden zwei Vormerken enthält 
    */

    @Test
    public void testGetAnzahlAnVormerkern()
    {
        _vormerkkarte = new Vormerkkarte(_kunde1, _medium);
        assertEquals(1, _vormerkkarte.getAnzahlAnVormerkern());

        _verleihService.fuegeVormerkerHinzu(_medium, _kunde2);
        assertEquals(2, _vormerkkarte.getAnzahlAnVormerkern());
    }

}
